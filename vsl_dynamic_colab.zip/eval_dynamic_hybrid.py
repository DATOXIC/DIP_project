"""
ĐÁNH GIÁ SO SÁNH HYBRID (DTW vs DEEP LEARNING vs HYBRID FUSION) TRÊN NGƯỜI LẠ
==============================================================================
Tác giả: Tô Phương Đạt (24110086) - Dự án DIP Project
Mục đích:
  - Kiểm chứng khoa học giả thuyết: "Deep Learning + DTW giúp giải quyết triệt để bài toán Người Lạ".
  - So sánh 3 phương pháp trên CÙNG 1 tập dữ liệu kiểm thử (unseen signer):
      1. DTW thuần túy (GoldenTriadDTWMatcher - cấu hình G1p90)
      2. Deep Learning thuần túy (LightweightGestureNet - 1D-CNN + Bi-GRU + Attention)
      3. Hybrid Late Fusion: Kết hợp xác suất DL với khoảng cách DTW.
  - In ra bảng đối sánh trực quan và xuất file báo cáo JSON.
"""

import os
import sys
import json
import argparse
from typing import Dict, List, Tuple, Any, Optional

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

import numpy as np
import torch
import torch.nn.functional as F

from train_dynamic_dl import LightweightGestureNet, TARGET_WORDS, load_all_sign_data
from scoreboard import build_matcher_from_config, load_bank, validate_and_hash_config


def evaluate_hybrid_on_signer(
    test_signer: str = "Dang",
    model_weights_path: Optional[str] = None,
    dtw_config_path: str = "configs/G1p90.json",
    bank_path: str = "webcam_templates.json",
    alpha: float = 0.65  # Trọng số ưu tiên Deep Learning khi gặp người lạ
):
    print("=" * 75)
    print(f"  ĐÁNH GIÁ SO SÁNH TRÊN NGƯỜI LẠ: [{test_signer}]")
    print(f"  Cấu hình: Alpha Fusion = {alpha:.2f} (DL) + {1.0 - alpha:.2f} (DTW)")
    print("=" * 75)

    word_to_id = {w: i for i, w in enumerate(TARGET_WORDS)}
    id_to_word = {i: w for w, i in word_to_id.items()}

    # 1. Nạp toàn bộ dữ liệu và lọc ra tập test của test_signer
    all_samples, _ = load_all_sign_data()
    test_samples = [s for s in all_samples if s["signer"] == test_signer]

    if len(test_samples) == 0:
        print(f"[LỖI] Không tìm thấy mẫu nào của người ký [{test_signer}]!")
        return

    print(f"-> Đã tìm thấy {len(test_samples)} mẫu cử chỉ của [{test_signer}].")

    # 2. Khởi tạo & nạp mô hình Deep Learning
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if model_weights_path is None or not os.path.exists(model_weights_path):
        model_weights_path = f"best_gesture_model_{test_signer}.pth"

    if not os.path.exists(model_weights_path):
        print(f"[!] Chưa có trọng số mô hình tại {model_weights_path}.")
        print(f"    Vui lòng chạy: py train_dynamic_dl.py --test_signer {test_signer} trước!")
        return

    dl_model = LightweightGestureNet(in_features=24, num_classes=len(TARGET_WORDS), hidden_dim=64).to(device)
    checkpoint = torch.load(model_weights_path, map_location=device)
    dl_model.load_state_dict(checkpoint["model_state_dict"])
    dl_model.eval()
    print(f"-> Đã nạp thành công mô hình Deep Learning: {model_weights_path}")

    # 3. Khởi tạo bộ so khớp DTW
    has_dtw = False
    dtw_matcher = None
    if os.path.exists(dtw_config_path) and os.path.exists(bank_path):
        try:
            cfg, _ = validate_and_hash_config(dtw_config_path)
            dat_bank, _ = load_bank(bank_path)
            dtw_matcher = build_matcher_from_config(cfg, dat_bank)
            has_dtw = True
            print(f"-> Đã nạp thành công bộ so khớp DTW: {dtw_config_path} + {bank_path}")
        except Exception as e:
            print(f"[CẢNH BÁO] Không thể nạp DTW matcher: {e}")

    # 4. Thực hiện đánh giá từng mẫu
    dtw_correct = 0
    dl_correct = 0
    hybrid_correct = 0

    per_word_stats: Dict[str, Dict[str, int]] = {}
    for s in test_samples:
        true_word = s["word"]
        traj = s["traj"]  # (32, 24)

        if true_word not in per_word_stats:
            per_word_stats[true_word] = {"total": 0, "dtw": 0, "dl": 0, "hybrid": 0}
        per_word_stats[true_word]["total"] += 1

        # A. Dự đoán qua Deep Learning
        with torch.no_grad():
            x_tensor = torch.from_numpy(traj[None, ...]).to(device)
            logits = dl_model(x_tensor)
            dl_probs = F.softmax(logits, dim=-1).cpu().numpy()[0]  # (13,)
            dl_pred_id = int(np.argmax(dl_probs))
            dl_pred_word = id_to_word[dl_pred_id]

        if dl_pred_word == true_word:
            dl_correct += 1
            per_word_stats[true_word]["dl"] += 1

        # B. Dự đoán qua DTW
        dtw_pred_word = "NONE"
        dtw_scores_13d = np.zeros(len(TARGET_WORDS), dtype=np.float32)

        if has_dtw and dtw_matcher is not None:
            try:
                shapes = s.get("hand_shapes", ["Unknown"] * 32)
                handed = s.get("handedness", "Right")
                chir = bool(s.get("chirality_canonical", True))
                has_body = s.get("body_anchor_valid", True)
                rep = s.get("rep_count")

                dtw_res = dtw_matcher.match(
                    query_traj_9d=np.asarray(traj, dtype=np.float32),
                    query_shapes=shapes,
                    handedness=("Right" if chir else handed),
                    query_has_body=has_body,
                    query_rep_count=rep
                )
                if dtw_res.candidates and len(dtw_res.candidates) > 0:
                    dtw_pred_word = dtw_res.candidates[0].word_key
                    for cand in dtw_res.candidates:
                        if cand.word_key in word_to_id:
                            w_idx = word_to_id[cand.word_key]
                            dtw_scores_13d[w_idx] = float(math.exp(-min(10.0, cand.total_cost)))

                sum_dtw = np.sum(dtw_scores_13d)
                if sum_dtw > 1e-6:
                    dtw_scores_13d /= sum_dtw
                elif dtw_pred_word in word_to_id:
                    dtw_scores_13d[word_to_id[dtw_pred_word]] = 1.0
            except Exception as e:
                pass

        if dtw_pred_word == true_word:
            dtw_correct += 1
            per_word_stats[true_word]["dtw"] += 1

        # C. Dự đoán qua Hybrid Fusion (Late Fusion)
        hybrid_scores = alpha * dl_probs + (1.0 - alpha) * dtw_scores_13d
        hybrid_pred_id = int(np.argmax(hybrid_scores))
        hybrid_pred_word = id_to_word[hybrid_pred_id]

        if hybrid_pred_word == true_word:
            hybrid_correct += 1
            per_word_stats[true_word]["hybrid"] += 1

    total = len(test_samples)
    dtw_acc = (dtw_correct / total) * 100.0 if total > 0 else 0.0
    dl_acc = (dl_correct / total) * 100.0 if total > 0 else 0.0
    hybrid_acc = (hybrid_correct / total) * 100.0 if total > 0 else 0.0

    # 5. In bảng kết quả so sánh
    print("\n" + "=" * 75)
    print(f"  BẢNG SO SÁNH ĐỘ CHÍNH XÁC (TOP-1 ACCURACY) TRÊN [{test_signer}]")
    print("=" * 75)
    print(f"  1. DTW Đơn thuần (Bank Đạt)       : {dtw_correct}/{total} mẫu ({dtw_acc:5.2f}%)")
    print(f"  2. Deep Learning Đa nguồn (CNN+GRU): {dl_correct}/{total} mẫu ({dl_acc:5.2f}%)")
    print(f"  3. HYBRID FUSION (DTW + DL)        : {hybrid_correct}/{total} mẫu ({hybrid_acc:5.2f}%)")
    print("-" * 75)
    print(f"{'Từ vựng':<12} | {'Tổng mẫu':<9} | {'DTW':<12} | {'Deep Learning':<15} | {'HYBRID FUSION':<15}")
    print("-" * 75)

    for w, st in sorted(per_word_stats.items()):
        n = st["total"]
        dtw_str = f"{st['dtw']}/{n} ({(st['dtw']/n)*100:4.0f}%)"
        dl_str = f"{st['dl']}/{n} ({(st['dl']/n)*100:4.0f}%)"
        hy_str = f"{st['hybrid']}/{n} ({(st['hybrid']/n)*100:4.0f}%)"
        print(f"{w:<12} | {n:<9} | {dtw_str:<12} | {dl_str:<15} | {hy_str:<15}")

    print("=" * 75)

    # 6. Ghi kết quả so sánh vào file JSON
    out_file = f"results_hybrid_{test_signer}.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "test_signer": test_signer,
            "total_samples": total,
            "dtw_accuracy": dtw_acc,
            "dl_accuracy": dl_acc,
            "hybrid_accuracy": hybrid_acc,
            "per_word": per_word_stats
        }, f, ensure_ascii=False, indent=2)
    print(f"\n✓ Đã lưu chi tiết so sánh tại: {out_file}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="So sánh DTW vs Deep Learning vs Hybrid trên người lạ")
    parser.add_argument("--test_signer", type=str, default="Dang", help="Tên người ký cần đánh giá (LOSO)")
    parser.add_argument("--weights", type=str, default=None, help="Đường dẫn file trọng số .pth")
    parser.add_argument("--alpha", type=float, default=0.65, help="Hệ số trọng số Deep Learning trong Hybrid")
    args = parser.parse_args()

    evaluate_hybrid_on_signer(
        test_signer=args.test_signer,
        model_weights_path=args.weights,
        alpha=args.alpha
    )
